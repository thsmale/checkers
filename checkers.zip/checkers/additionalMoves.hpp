#ifndef additional_moves_hpp
#define additional_moves_hpp

#include<iostream>
#include<vector>
#include<string>
#include<utility>
#include<locale>

std::vector<std::pair<int,int> > additional_moves(std::vector<std::vector<char> > board, int x, int y, bool isWhite, bool isKing);

#endif
